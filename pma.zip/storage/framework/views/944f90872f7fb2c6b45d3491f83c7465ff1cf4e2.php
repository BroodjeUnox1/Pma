
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-10 text-center">
		<h1>Voortgang</h1>
	</div>
</div>
<hr>

	<div class="row">
	<form method="POST" action="voortgang" class="col-md-12">
		<div class="row">
		<?php echo csrf_field(); ?>
		<div class="col-md-2 offset-md-1">
			<label>Student</label>
			<input type="text" class="form-control" placeholder="Student" name="student">
		</div>
		<div class="col-md-2">
			<label>Klas:</label>
			<select name="klas" id="" class="form-control">
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
			</select>
		</div>
		<div class="col-md-2">
			<label>leerjaar:</label>
			<select name="leerjaar" id="" class="form-control">
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
			</select>
		</div>
		<div class="col-md-2">
			<label>­</label>
			<button class="btn btn-success btn-block" type="submit">Zoek</button>
		</div>
	
		<div class="col-md-2">
			<label>­</label>
			<a href="voortgang"><button class="btn btn-info btn-block" type="button">refresh</button></a>
		</div>
	</div>
	</form>
		
	</div>

<div class="row">
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-4 mt-3">
		<div class="card">
			<div class="card-header"><h1><?php echo e($row['name']); ?></h1></div>
			<div class="card-body">
				<div class="row">
					<div class="col-md-6">
						<h3>klas:<?php echo e($row['klas']); ?></h3>
						<h3>leerjaar:<?php echo e($row['leerjaar']); ?></h3>
					</div>
					<div class="col-md-6 text-center">
						<i class="fas fa-user fa-5x" ></i>
					</div>
				</div>
				
			</div>
			<div class="card-footer">
				<div class="row">
					<div class="col-md-6"><a href="voortgang/<?php echo e($row['id']); ?>"><button class="btn btn-success">Kijk voortgang</button></a></div>
				</div>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/voortgang.blade.php ENDPATH**/ ?>