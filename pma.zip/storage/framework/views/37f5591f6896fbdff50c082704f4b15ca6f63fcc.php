
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12 text-center">
		<h1>Planningen</h1>
	</div>
</div>
<hr>

<div class="row mt-5">
	<div class="col-md-6 offset-md-3">
		<!-- check voor of die niet een student is laat andere dingen zien -->
		<?php if(!Illuminate\Support\Facades\Auth::user()->hasRole("student")): ?>
		<form method="POST" action="planningen">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-md-3">
					<div class="form-group">
						<label>Klas:</label>
						<select class="form-control" name="klas">
							<option <?php echo e($klas == 1 ? 'selected' : 'class'); ?>>1</option>
							<option <?php echo e($klas == 2 ? 'selected' : 'class'); ?>>2</option>
							<option <?php echo e($klas == 3 ? 'selected' : 'class'); ?>>3</option>
							<option <?php echo e($klas == 4 ? 'selected' : 'class'); ?>>4</option>
						</select>
					</div>
				</div>
				<div class="col-md-3">
					<div class="form-group">
						<label>Periode:</label>
						<select class="form-control" name="periode" >
							<option <?php echo e($periode == 1 ? 'selected' : 'class'); ?>>1</option>
							<option <?php echo e($periode == 2 ? 'selected' : 'class'); ?>>2</option>
							<option <?php echo e($periode == 3 ? 'selected' : 'class'); ?>>3</option>
							<option <?php echo e($periode == 4 ? 'selected' : 'class'); ?>>4</option>
						</select>
					</div>
				</div>
				<div class="col-md-3">
					<div class="form-group">
						<label>Leerjaar</label>
						<select class="form-control" name="leerjaar">
							<option <?php echo e($leerjaar == 1 ? 'selected' : 'class'); ?>>1</option>
							<option <?php echo e($leerjaar == 2 ? 'selected' : 'class'); ?>>2</option>
							<option <?php echo e($leerjaar == 3 ? 'selected' : 'class'); ?>>3</option>
							<option <?php echo e($leerjaar == 4 ? 'selected' : 'class'); ?>>4</option>
						</select>
					</div>
				</div>
				<div class="col-md-3">
					<div class="form-group">
						<label>­</label>
						<button type="submit" class="btn btn-block btn-success" name="submit">Search</button>
					</div>
				</div>
			</div>

			
			
		</form>
		<?php else: ?>
		<!-- als hij of zij een student is laar alleen periode selector zien -->
		<form method="POST" action="planningen">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-md-10">
					<div class="form-group">
						<label>Periode:</label>
						<select class="form-control" name="periode" >
							<option <?php echo e($periode == 1 ? 'selected' : 'class'); ?>>1</option>
							<option <?php echo e($periode == 2 ? 'selected' : 'class'); ?>>2</option>
							<option <?php echo e($periode == 3 ? 'selected' : 'class'); ?>>3</option>
							<option <?php echo e($periode == 4 ? 'selected' : 'class'); ?>>4</option>
						</select>
					</div>
				</div>
				<div class="col-md-2">
					<div class="form-group">
						<label>­</label>
						<button type="submit" class="btn btn-block btn-success" name="submit">Search</button>
					</div>
				</div>
			</div>
			
			
		</form>

		<?php endif; ?> 
	</div>
</div>

<!-- check of data niet leeg is is die leeg laat niks zien -->
<?php if(!empty($data)): ?>
<div class="row mt-3">
	<div class="col-md-12">
		<table width="100%" border="1" class="table table-striped" id="table">
			<thead>
				<tr>
					<td class="text-white"><b>Klas</b></td>
					<td class="text-white"><b>Vak</b></td>
					<td class="text-white"><b>Onderwerp</b></td>
					<td class="text-white"><b>Periode</b></td>
					<td class="text-white"><b>Leerjaar</b></td>
					<td class="text-white"><b>Opdracht</b></td>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class="<?php echo e($row['id']); ?>">
					<td><?php echo e($row['klas']); ?></td>
					<td><a href="planningen/<?php echo e($row['id']); ?>"><?php echo e($row['vak']); ?></a></td>
					<td><?php echo e($row['onderwerp']); ?></td>
					<td><?php echo e($row['periode']); ?></td>
					<td><?php echo e($row['leerjaar']); ?></td>
					<td><?php echo e($row['opdrachten']); ?></td>
				</tr>	
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			
		</table> 
	</div>
</div>
<?php endif; ?>
<?php if(Illuminate\Support\Facades\Auth::user()->hasRole("student")): ?>
<textarea class="form-control mt-5" placeholder="<?php echo e(empty($feedback) ? 'nog geen feedback' : $feedback['feedback']); ?>" disabled=""></textarea>
<?php endif; ?>

<script>
	$(document).ready(function(){
        $('#table').DataTable()        
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/planningen.blade.php ENDPATH**/ ?>