
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-10 text-center">
		<h1>Update Cursus: <?php echo e($info["name"]); ?></h1>
	</div>
	<div class="col-md-2">
		<a href="/cursussen"><h1>terug</h1></a>
	</div>
</div>
<hr>

<form method="POST" action="create-cursus">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col-md-8 offset-md-2">
			<div class="row addopdracht">
				<div class="col-md-4">	
					<div class="form-group">
						<label>Vak:</label>
						<input type="text" name="vak" required="" placeholder="Vakken" class="form-control" value="<?php echo e($info['vak']); ?>">
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label>Onderwerp:</label>
						<input type="text" name="onderwerp" required="" placeholder="Onderwerp" class="form-control" value="<?php echo e($info['onderwerp']); ?>">
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label>Klas:</label>
						<input type="text" name="klas" required="" placeholder="Klas" class="form-control" value="<?php echo e($info['klas']); ?>">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Periode:</label>
						<input type="text" name="periode" required="" placeholder="Periode" class="form-control" value="<?php echo e($info['periode']); ?>">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Leerjaar:</label>
						<input type="text" name="leerjaar" required="" placeholder="leerjaar" class="form-control" value="<?php echo e($info['leerjaar']); ?>">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Opdrachten:</label>
						<input type="text" name="opdrachten" required="" placeholder="Opdrachten" class="form-control" value="<?php echo e($info['opdrachten']); ?>">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Extra info:</label>
						<input type="text" name="info" required="" placeholder="Extra info" class="form-control" value="<?php echo e($info['info']); ?>">
					</div>
				</div>
				<input type="hidden" name="id" value="<?php echo e($info['id']); ?>">
				<div class="col-md-12 mt-3">
					<div class="form-group">
						<button class="btn btn-block btn-success" type="submit" name="submit">Update</button>
					</div>
				</div>
				<?php
				$data = json_decode($info['opdrachtlist']);
				$i=1;
				?>

				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-12 mt-3" id="<?php echo e($i); ?>">
					<label>Les: <?php echo e($i); ?></label>
					<input type="text" name="opdracht<?php echo e($i); ?>" value="<?php echo e($row); ?>" class="form-control">
				</div>
				<?php
				$i +=1;
				?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>

		</div>
	</div>
	
</form>
<div class="row">
	<div class="col-md-3 offset-md-2">
		<button class="btn btn-block btn-success" onclick="add()">Voeg een les toe</button>
	</div>
	<div class="col-md-3 offset-md-2">
		<button class="btn btn-block btn-danger" onclick="remove()">Verwijder les</button>
	</div>

</div> 

<!-- simpele script voor voor extra opdrachten toe te voegen -->
<script type="text/javascript">
	function add() {
		var last = $(".addopdracht .col-md-12").last().attr("id")
		console.log(last)
		last = parseInt(last) + 1
		$(".addopdracht").append("<div class='col-md-12 mt-3' id='"+ last +"'><label>les: "+ last + ":</label><input type='text' name='opdracht"+last+"' placeholder='Opdracht' class='form-control' required=''></div>") 
	}

	function remove() {
		var last = $(".addopdracht .col-md-12").last()
		if(last.attr('id') != 1){
			last.remove();
		}
		
	}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/update-cursus.blade.php ENDPATH**/ ?>