<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="	sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />

<!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <style type="text/css">
    	html, body {
	height: 100%;
	background: #808080/*rgb(131,72,208)*/;
    background: linear-gradient(135deg, rgba(131,72,208,1) 0%, rgba(57,122,218,1) 50%, rgba(0,212,255,1) 100%);
    margin: 0px;
    overflow-x: hidden;
    color: #818181;
}
    /* The side navigation menu */
	.sidenav {
  height: 100%; /* 100% Full-height */
  width: 250px; /* 0 width - change this with JavaScript */
  position: fixed; /* Stay in place */
  z-index: 1; /* Stay on top */
  top: 0; /* Stay at the top */
  left: 0;
  background-color: #FFFAFA; /* Black*/
  overflow-x: hidden; /* Disable horizontal scroll */
  padding-top: 60px; /* Place content 60px from the top */
  /*transition: 0.5s;  *//*0.5 second transition effect to slide in the sidenav */
  border-radius: 0px 7px 7px 0px;
}

/* The navigation menu links */
.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

/* When you mouse over the navigation links, change their color */
.sidenav a:hover {
  color: #f1f1f1;
}

/* Position and style the close button (top right corner) */
.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

.content-background {
	background-color: #FFFAFA;
	border-radius: 7px; 
	min-height: 85vh;
}
    </style>
}
</head>
<body>
		<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <a href="./index.php?content=about" style="">About</a>
	  <a href="./index.php?content=services">Services</a>
	  <a href="#">Clients</a>
	  <a href="./index.php?content=contact">Contact</a>
	  <a href="./login">Login</a>
	  <a href="./register">Register</a>
	  <a href="./register">Register</a>
	</div>
	
	<div style="margin-left: 8px; font-size: 200%;">
		<span onclick="openNav()"><i class="fas fa-bars"></i></span>
	</div>
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-9 offset-md-2">
			<div class="container-fluid content-background d-flex flex-column">
				<div class="row my-auto">
					<div class="col-md-12">
						<h1>test</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

function loadNav() {
	$(".sidenav").css("transition", "0.0s")
	if($(".sidenav").css("width") == "0px") {
		$(".sidenav").css("width", "250px");
		setTimeout(
  			function(){
  				$(".sidenav").css("transition", "0.5s")
  			}, 500);
	}
}
</script>
</body>
</html><?php /**PATH C:\Projects_Laravel\pma\resources\views/panel.blade.php ENDPATH**/ ?>