
<?php $__env->startSection('content'); ?>
   
    <div class="row mt-5">
    <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
    <div class="card">
        <div class="card-header">
            <p>Type: <?php echo e($pizza['type']); ?></p>
            <?php if($loop->first): ?>
            <span>eerste</span>
            <?php endif; ?>
            <?php if($loop->last): ?>
            <span>laatste</span>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <p>bodem: <?php echo e($pizza['base']); ?></p>
        </div>
        <div class="card-footer">
            <p>prijs: <?php echo e($pizza['price']); ?></p>
        </div>
    </div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/test.blade.php ENDPATH**/ ?>