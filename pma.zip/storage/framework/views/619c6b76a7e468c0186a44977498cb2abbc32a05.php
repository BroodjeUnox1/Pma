
<?php $__env->startSection('content'); ?>

<?php if(!empty($cursus)): ?>
<!-- decode de json zodat het bewerk baar is als een array -->
<?php
$data = json_decode($cursus["opdrachtlist"]);
?>
<div class="row">
	<div class="col-md-10 text-center">
		<h1>Opdrachten</h1>
	</div>
	<div class="col-md-2">
			<a href="/planningen"><h1>Terug</h1></a>
	</div>
</div>
<hr>
<div class="row">
	<div class="col-md-10 offset-md-1 mt-3">
			<div class="row">
				<div class="col-md-6">	
					<div class="form-group">
						<label>Vak:</label>
						<input type="text" name="vak" required="" class="form-control" value="<?php echo e($cursus['vak']); ?>" disabled="">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Onderwerp:</label>
						<input type="text" name="onderwerp" required="" class="form-control" value="<?php echo e($cursus['onderwerp']); ?>" disabled="">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Opdrachten:</label>
						<input type="text" name="opdrachten" required="" class="form-control" value="<?php echo e($cursus['opdrachten']); ?>" disabled="">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Extra info:</label>
						<input type="text" name="info" required="" class="form-control" value="<?php echo e($cursus['info']); ?>" disabled="">
					</div>
				</div>
				
			</div>
			<div class="row">
			<!-- set de value i zodat ik weet voor welke vak ik hem update -->
			<?php
			$i = 1;
			?>
			<!-- output elke opdracht voor dit vak -->
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<form action="" method="POST" class="col-md-12">
				<?php echo csrf_field(); ?>
				<div class="row">
					<?php if(Illuminate\Support\Facades\Auth::user()->hasRole("student")): ?>
					<div class="col-md-6 form-group">
						<label>Les <?php echo e($i); ?>:</label>
						<input type="txt" name="" value="<?php echo e($row); ?>" class="form-control" disabled="">
					</div>
					
					<div class="col-md-3 form-group">
						<label>Af tot:</label>
						<select class="form-control" name="progressie" id="<?php echo e($i); ?>" style="color: red;">
							<option value="Niet af" style="color: red;">Niet af</option>
							<option value="Bijna af" style="color: orange;">Bijna af</option>
							<option value="Af" style="color: green;">Af</option>
						</select>
					</div>
					<input type="hidden" name="vak_id" value="<?php echo e($i); ?>">
					<div class="col-md-3">
						<label>­</label>
						<button class="btn btn-block btn-success" type="submit" id="<?php echo e($i); ?>">Update</button>
					</div>
					<?php else: ?>
					<div class="col-md-6 form-group">
						<label>Les <?php echo e($i); ?>:</label>
						<input type="txt" name="" value="<?php echo e($row); ?>" class="form-control" disabled="">
					</div>
					<?php endif; ?>
				</div>
			</form>
			<!-- Plus 1 zodat voor elk nieuwe vak een specifiek id heeft -->
			<?php
			$i += 1;
			?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</div>
		</div>

</div>

<?php $__currentLoopData = $progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">
	$("select#<?php echo e($row['vak_id']); ?>.form-control option[value='<?php echo e($row['beoordeling']); ?>']").attr('selected', 'selected')
	if("<?php echo e($row['beoordeling']); ?>" == 'Af'){
		$("select#<?php echo e($row['vak_id']); ?>.form-control ").css('color', 'green')
	}else if("<?php echo e($row['beoordeling']); ?>" == 'Bijna af'){
		$("select#<?php echo e($row['vak_id']); ?>.form-control").css('color', 'orange')
	}else {
		$("select#<?php echo e($row['vak_id']); ?>.form-control").css('color', 'red')
	}
</script>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="alert alert-danger mt-5" role="alert">
  	Geen data bij dit ID probeer een andere.
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/oneitem.blade.php ENDPATH**/ ?>