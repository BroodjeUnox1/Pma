
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-10 text-center">
		<h1>Maak een klas</h1>
	</div>
	<div class="col-md-2">
		<a href="/klassen"><h1>Terug</h1></a>
	</div>
</div>
<hr>

<?php
$myarray = array();	

foreach($klassen as $row) {
	for($i=1;$i<6;$i++){
		array_push($myarray, $row["leerling$i"]);
	}

}

$geenKlas = array();
foreach($users as $row){
	if(!in_array($row['id'], $myarray)){
		array_push($geenKlas, $row["id"]);
	}


}


?>

<div class="row">
	<div class="col-md-6 offset-md-3">
		<h1>Studenten:</h1>
	</div>
	<div class="col-md-6 offset-md-3">
		<form action="create-klassen" method="POST">
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label>Leerling 1:</label>
				<select class="form-control" name="leerling1" required="">
					<?php $__currentLoopData = $geenKlas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option><?php echo e($row2); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label>Leerling 2:</label>
				<select class="form-control" name="leerling2" required="">
					<?php $__currentLoopData = $geenKlas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option><?php echo e($row2); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label>Leerling 3:</label>
				<select class="form-control" name="leerling3" required="">
					<?php $__currentLoopData = $geenKlas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option><?php echo e($row2); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label>Leerling 4:</label>
				<select class="form-control" name="leerling4" required="">
					<?php $__currentLoopData = $geenKlas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option><?php echo e($row2); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label>Leerling 5:</label>
				<select class="form-control" name="leerling5" required="">
					<?php $__currentLoopData = $geenKlas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option><?php echo e($row2); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<input type="text" name="klas" placeholder="Klas code" class="form-control" required=""> 
			</div>
			<div class="form-group">
				<input type="text" name="leerjaar" placeholder="leerjaar" class="form-control" required="">
			</div>
			<div class="form-group">
				<button type="submit" name="submit" class="btn btn-block btn-success">Maak klas</button>
			</div>
		</form>
	</div>
</div>



<!-- <?php $__currentLoopData = $klassen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php for($i=1;$i<6;$i++): ?>
	
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($user["id"] == $row["leerling$i"]): ?>
			<?php echo e($user["id"]); ?>

		<?php else: ?> 
			k
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endfor; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?> -->
<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/create-klassen.blade.php ENDPATH**/ ?>