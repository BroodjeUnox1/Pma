
<?php $__env->startSection('content'); ?>
<div class="row mt-5">
	<div class="col-md-10 offset-md-2">
		<small><?php $timestamp = time(); setlocale(LC_ALL, 'nl_NL'); echo strftime('%d %B, %Y', $timestamp);?></small>
	</div>
	<div class="col-md-10 offset-md-2">
		<h1>Welkom: <?php echo e(Illuminate\Support\Facades\Auth::user()['name']); ?></h1>
	</div>
	<div class="col-md-12 text-center mt-5">
		<img src="./images/loginlogo.png">
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/admin/admin-page.blade.php ENDPATH**/ ?>