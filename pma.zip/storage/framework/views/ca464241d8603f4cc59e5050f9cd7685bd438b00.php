

<!DOCTYPE html>
<html>
<head>
    <title>
        
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="    sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="/css/main.css">
</head>
<body>
    <div id="mySidenav" class="sidenav">
        <h1>student page</h1>
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
<!--         <a href="/cursussen" style="">cursussen</a> -->
        <a href="/home" style="">Home</a>
        <a href="/planningen" style="">planning</a>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                this.closest(\'form\').submit();']); ?>
                <?php echo e(__('Log out')); ?>

             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </form>
    </div>
    
    <div style="margin-left: 8px; font-size: 200%;">
        <span onclick="openNav()"><i class="fas fa-bars"></i></span>
    </div>
    <div class="container-fluid">
    <div class="row">
        <div class="col-md-9 offset-md-2">
            <div class="container-fluid content-background d-flex flex-column">
                <div class="row">
                    <div class="col-md-12">
                       student
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

function loadNav() {
    $(".sidenav").css("transition", "0.0s")
    if($(".sidenav").css("width") == "0px") {
        $(".sidenav").css("width", "250px");
        setTimeout(
            function(){
                $(".sidenav").css("transition", "0.5s")
            }, 500);
    }
}
</script>

<script type="text/javascript">
    $(".card").hover(function() {
        $(this).css("box-shadow", "0px 0px 5px 2px #000000");
    }, function() {
        $(this).css("box-shadow", "none");
    })

</script>
</body>
</html><?php /**PATH C:\Projects_Laravel\pma\resources\views/student-page.blade.php ENDPATH**/ ?>