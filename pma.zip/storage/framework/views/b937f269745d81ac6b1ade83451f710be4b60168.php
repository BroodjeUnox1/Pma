
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-10 text-center">
        <h1>Cursus: <?php echo e($info["name_cursus"]); ?></h1>
    </div>
    <div class="col-md-2">
        <a href="/create-cursus"><h1>Maak</h1></a>
    </div>
</div>
<hr>
   <div class="card mx-auto mt-5" style="max-height: 18rem; min-height: 18rem; max-width: 28rem;">
       <div class="card-header">
           <h3><?php echo e($info["name_cursus"]); ?></h3>
       </div>
       <div class="card-body overflow-y">
                <h6><?php echo e($info['Numbers']); ?></h6>
                <hr>
                <h5 class="mt-2"><?php echo e($info['description']); ?></h5>
            </div>

       <div class="card-footer">
           <h4>Week: <?php echo e($info['week']); ?></h4>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/singel-cursus.blade.php ENDPATH**/ ?>