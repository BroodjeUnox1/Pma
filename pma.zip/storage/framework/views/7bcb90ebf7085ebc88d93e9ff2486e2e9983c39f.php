
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 text-center">
        <h1>Student: <?php echo e($info["name"]); ?></h1>
    </div>
</div>
<hr>
    
<form action="update-student" method="post">
    <?php echo csrf_field(); ?>
    <div class="card mx-auto mt-5" style="max-height: 20rem; min-height: 18rem; max-width: 28rem;">
       <div class="card-header">
           <h3><?php echo e($info["name"]); ?></h3>
           <input type="hidden" name="id" value="<?php echo e($info['id']); ?>">
       </div>
       <div class="card-body overflow-y">
            <select class="form-control" name="option">
                <option value="2">admin</option>
                <option value="3">docent</option>
                <option value="4">student</option>
            </select>
            <input type="text" name="klas" placeholder="Klas" class="form-control mt-3" value="<?php echo e($info['klas']); ?>">
            <input type="text" name="leerjaar" placeholder="Leerjaar" class="form-control mt-3" value="<?php echo e($info['leerjaar']); ?>">

        </div>

        <div class="card-footer text-right">
            <button class="btn btn-success">update</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/root/update-student.blade.php ENDPATH**/ ?>