
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-10 text-center">
        <h1>Cursus: <?php echo e($info["name"]); ?></h1>
    </div>
    <div class="col-md-2">
        <a href="/planningen"><h1>terug</h1></a>
    </div>
</div>
<hr>
<div class="card mx-auto mt-5" style="max-height: 25rem; min-height: 21rem; max-width: 28rem;">
   <div class="card-header">
       <h4><?php echo e($info["name"]); ?></h4>
   </div>
   <div class="card-body overflow-y">
        <table style="width: 100%;" border="1">
            <tbody>
              <tr>//
                <td width="10%"></td>
                <td width="20%" style="color: white"><b>Opdrachten</b></td>
                <td style="color: white"><b>Info</b></td>
              </tr>
              <?php for($i=1;$i<7;$i++): ?>
              <tr>
                <td style="color: black"><b><?php echo e($list[$i]); ?></b></td>
                <td><?php echo e($info["num$i"]); ?></td>
                <td><?php echo e($info["info$i"]); ?></td>
              </tr>
              <?php endfor; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <h4>Week: <?php echo e($info['week']); ?></h4>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/student/singel-cursus.blade.php ENDPATH**/ ?>