
<?php $__env->startSection('content'); ?>
<h1>test</h1>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.basic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects_Laravel\pma\resources\views/index.blade.php ENDPATH**/ ?>